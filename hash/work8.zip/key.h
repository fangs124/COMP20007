/* 
** COMP200007 Design of Algorithms 
**
** Author: Andrew Turpin
** Wed  8 May 2013 19:21:49 EST
*/

#define KEY_PRINT_FORMAT "%d "

typedef int Key;             // integer keys

int keyCmp(const void *a, const void *b);
